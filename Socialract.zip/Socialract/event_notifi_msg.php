
<?php
$servername = "localhost";
$username = "doctorca_Myspot";
$password = "doctorca_Myspot";
$dbname = "doctorca_Myspot";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM offers";
$result = $conn->query($sql);
// 2019-09-30

$currnet_date = date('Y-m-d');
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        
        $event_date = $row['date_to'];
      
      if($currnet_date > $event_date){
      //   echo "yessssssss";
       //  echo "<pre/>";
      /// $sql1 = "DELETE FROM `event` WHERE `event_date` = '$event_date'";
      $sql1 = "UPDATE `offers` SET valid_offer='expired' WHERE `date_to` ='$event_date'";
       
       $result2 = $conn->query($sql1);
      }else{
          echo "no";
           echo $event_date;
         echo "<pre/>";
      }  
        // print_r($currnet_date);
        // print_r($event_date);die;
    }
} else {
    echo "0 results";
}
$conn->close();
?>
