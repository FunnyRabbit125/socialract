<?php
        $data = [
    // 'phone' => '79995253422', // Receivers phone
    'phone' => '918085398750', // Receivers phone
    'body' => 'Hello, Andrew!', // Message
];
$json = json_encode($data); // Encode data to JSON
// URL for request POST /message
$url = 'https://api.chat-api.com/message?token=83763g87x';
// Make a POST request
$options = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-type: application/json',
        'content' => $json
    ]
]);
// Send a request
$result = file_get_contents($url, false, $options);

?>