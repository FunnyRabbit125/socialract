
<?php
$servername = "localhost";
$username = "MuscatKidz";
$password = "MuscatKidz";
$dbname = "MuscatKidz";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//print_r($conn);die;

 $date = date('Y-m-d');


    
    $noti = "SELECT * FROM notification WHERE date = '$date'"; 
$result = $conn->query($noti);

while($row = $result->fetch_assoc())
{
       //print_r($row);die;
                $userIds =$row['userIds'];
                $users = "SELECT * FROM users WHERE id IN($userIds)" ;
            //  
                    $u =$conn->query($users);
                
                        $description = $row['description'];
                        $userIds = $row['userIds']; 
                        $noti_type = $row['noti_type']; 
                      // $img = $arr_data['image']; 
                         $img_url = 'http://slvoman.com/MuscatKidz/uploads/images/'.$row['image'];
            //     //   print_r($img_url);die;
                while($u_data = $u->fetch_assoc()){

                   
                          $user_message_apk = array(
                             
                              "result" => "successful",
        					  "key" => "Notification from Admin",
        					  'event_image'=>$img_url,
        					  'message' => $description  
                
                          );
                          
                        //  print_r($user_message_apk);die;
                          $register_userid = array(
                              $u_data['register_id']
                          );
                      user_apk_notification($register_userid, $user_message_apk);
          
                }
           }   
   
   

// Noti
        	function user_apk_notification($registration_ids, $message){

			// Set POST variables
	        //	print_r($message);
			$url = 'https://fcm.googleapis.com/fcm/send';
			$fields = array(
				'registration_ids' => $registration_ids,
				'data' => $message,
			);
			$headers = array(
				'Authorization: key=' . "AAAAOPudvn8:APA91bFRG9jprG8Z7_D6oRpI2oWs_EFuWuTl0hFARPEAMjZFGWf9GEJ09UQQLQNsx-CUY6Oh3ZRTou8eaMh10PFtEuRwudjpuru01Pa6_k8AK2q0aJO4f8KVQYMABMLvWi4AukZdH7uF",
				'Content-Type: application/json'
			);

			// print_r($headers);
			// Open connection

			$ch = curl_init();

			// Set the url, number of POST vars, POST data

			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			// Disabling SSL Certificate support temporarly

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

			// Execute post

			$result = curl_exec($ch);
			if ($result === FALSE)
				{
				die('Curl failed: ' . curl_error($ch));
				}

			// Close connection

			curl_close($ch);

		//	echo $result;

			}
			


?>

